<script>
    export let name;
    export let url;
  </script>
  
  <a href="{url}" class="inline-block">
    <button class="px-4 py-2 bg-blue-500 text-white border-none cursor-pointer rounded-md transition-all duration-300 hover:bg-blue-700">
      {name}
    </button>
  </a>
  
  
  <style>
    /* Your other styles */
  
  </style>